# JFrog Pipelines Quickstart: Hello World

Sources for [Pipeline Example: Hello World](https://www.jfrog.com/confluence/display/JFROG/Pipeline+Example%3A+Hello+World)

## Prerequisites

- Integrations
  - tsuyo_github: GitHub
